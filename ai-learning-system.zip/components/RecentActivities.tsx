'use client';

import { CheckCircle, BookOpen, Award, Target } from 'lucide-react';

interface Activity {
  id: number;
  type: 'completed' | 'quiz' | 'achievement' | 'goal';
  title: string;
  description: string;
  timestamp: string;
  icon: React.ReactNode;
  color: string;
}

export default function RecentActivities() {
  const activities: Activity[] = [
    {
      id: 1,
      type: 'completed',
      title: 'Lesson Completed',
      description: 'Photosynthesis - Plant Biology',
      timestamp: '2 hours ago',
      icon: <BookOpen className="w-5 h-5" />,
      color: 'from-green-600 to-emerald-500',
    },
    {
      id: 2,
      type: 'quiz',
      title: 'Quiz Score',
      description: 'Physics Mechanics - 92%',
      timestamp: '5 hours ago',
      icon: <Target className="w-5 h-5" />,
      color: 'from-blue-600 to-cyan-500',
    },
    {
      id: 3,
      type: 'achievement',
      title: 'Achievement Unlocked',
      description: 'Perfect Score - 10 correct answers in a row',
      timestamp: '1 day ago',
      icon: <Award className="w-5 h-5" />,
      color: 'from-yellow-600 to-orange-500',
    },
    {
      id: 4,
      type: 'completed',
      title: 'Lesson Completed',
      description: 'Organic Chemistry - Alkanes',
      timestamp: '2 days ago',
      icon: <CheckCircle className="w-5 h-5" />,
      color: 'from-purple-600 to-pink-500',
    },
    {
      id: 5,
      type: 'goal',
      title: 'Daily Goal Met',
      description: 'Completed 90 minutes of study time',
      timestamp: '2 days ago',
      icon: <Target className="w-5 h-5" />,
      color: 'from-red-600 to-orange-500',
    },
  ];

  return (
    <div className="bg-card border border-border rounded-2xl p-8">
      <h2 className="text-2xl font-bold text-white mb-8">Recent Activities</h2>

      <div className="space-y-4">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-center gap-4 p-4 bg-background/50 border border-border rounded-lg hover:border-primary/50 hover:bg-background/70 transition-all">
            {/* Icon */}
            <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${activity.color} flex items-center justify-center text-white flex-shrink-0`}>
              {activity.icon}
            </div>

            {/* Content */}
            <div className="flex-1">
              <h4 className="text-white font-semibold">{activity.title}</h4>
              <p className="text-slate-400 text-sm">{activity.description}</p>
            </div>

            {/* Timestamp */}
            <div className="text-right">
              <p className="text-slate-400 text-xs font-medium">{activity.timestamp}</p>
            </div>
          </div>
        ))}
      </div>

      {/* View All Button */}
      <button className="w-full mt-6 py-3 px-4 border border-border hover:bg-background/50 text-white font-medium rounded-lg transition-colors">
        View All Activities
      </button>
    </div>
  );
}
