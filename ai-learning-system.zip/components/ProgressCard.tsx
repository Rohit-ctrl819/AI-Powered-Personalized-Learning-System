'use client';

interface ProgressCardProps {
  subject: string;
  percentage: number;
  color: string;
}

export default function ProgressCard({ subject, percentage, color }: ProgressCardProps) {
  return (
    <div className="bg-card border border-border rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-white font-semibold">{subject}</h3>
        <span className={`text-lg font-bold bg-gradient-to-r ${color} bg-clip-text text-transparent`}>
          {percentage}%
        </span>
      </div>
      <div className="w-full bg-background rounded-full h-3 overflow-hidden">
        <div
          className={`bg-gradient-to-r ${color} h-full rounded-full transition-all duration-500`}
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
      <div className="flex items-center justify-between mt-3">
        <span className="text-xs text-slate-400">Progress</span>
        <span className="text-xs text-slate-500">
          {Math.round((percentage / 100) * 50)} / 50 points
        </span>
      </div>
    </div>
  );
}
