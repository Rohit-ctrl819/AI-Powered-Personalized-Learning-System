'use client';

import { useState } from 'react';
import { Flame, Target, BookOpen, TrendingUp, Clock, Brain } from 'lucide-react';
import ProgressCard from './ProgressCard';
import AIRecommendations from './AIRecommendations';
import EmotionAnalysis from './EmotionAnalysis';
import RecentActivities from './RecentActivities';

export default function Dashboard() {
  const [studentName] = useState('Alex Johnson');
  const [studyStreak] = useState(12);

  return (
    <div className="min-h-screen bg-background p-6 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-border rounded-2xl p-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Welcome back, {studentName}! 👋</h1>
              <p className="text-slate-400 text-lg">Let&apos;s continue your learning journey</p>
            </div>
            <div className="hidden md:flex items-center gap-6">
              <div className="text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Flame className="w-6 h-6 text-orange-500" />
                  <span className="text-3xl font-bold text-white">{studyStreak}</span>
                </div>
                <p className="text-slate-400 text-sm">Day Streak</p>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <StatCard
            icon={<Brain className="w-6 h-6" />}
            label="Learning Progress"
            value="68%"
            color="from-blue-600 to-blue-400"
            change="+5% this week"
          />
          <StatCard
            icon={<Target className="w-6 h-6" />}
            label="Daily Goal"
            value="75 min"
            color="from-purple-600 to-purple-400"
            change="On track"
          />
          <StatCard
            icon={<TrendingUp className="w-6 h-6" />}
            label="Accuracy Rate"
            value="82%"
            color="from-cyan-600 to-cyan-400"
            change="+3% improvement"
          />
          <StatCard
            icon={<Clock className="w-6 h-6" />}
            label="Hours Studied"
            value="24.5h"
            color="from-pink-600 to-pink-400"
            change="This month"
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Progress Cards and Emotion Analysis */}
          <div className="lg:col-span-2 space-y-8">
            {/* Subject Progress */}
            <div>
              <div className="flex items-center gap-2 mb-6">
                <BookOpen className="w-6 h-6 text-blue-500" />
                <h2 className="text-2xl font-bold text-white">Subject-wise Performance</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <ProgressCard subject="Mathematics" percentage={78} color="from-blue-600 to-cyan-500" />
                <ProgressCard subject="Physics" percentage={72} color="from-purple-600 to-pink-500" />
                <ProgressCard subject="Chemistry" percentage={85} color="from-green-600 to-emerald-500" />
                <ProgressCard subject="Biology" percentage={68} color="from-orange-600 to-red-500" />
              </div>
            </div>

            {/* Emotion Analysis */}
            <EmotionAnalysis />
          </div>

          {/* Right Column - AI Recommendations */}
          <div>
            <AIRecommendations />
          </div>
        </div>

        {/* Recent Activities */}
        <RecentActivities />
      </div>
    </div>
  );
}

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: string;
  color: string;
  change: string;
}

function StatCard({ icon, label, value, color, change }: StatCardProps) {
  return (
    <div className="bg-card border border-border rounded-xl p-6 hover:border-primary/50 transition-all">
      <div className={`w-12 h-12 bg-gradient-to-br ${color} rounded-lg flex items-center justify-center text-white mb-4`}>
        {icon}
      </div>
      <p className="text-slate-400 text-sm font-medium mb-2">{label}</p>
      <p className="text-2xl font-bold text-white mb-2">{value}</p>
      <p className="text-xs text-slate-500">{change}</p>
    </div>
  );
}
