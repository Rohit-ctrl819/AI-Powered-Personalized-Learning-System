'use client';

import { Lightbulb, BookMarked, TrendingDown, Zap } from 'lucide-react';

export default function AIRecommendations() {
  const recommendations = [
    {
      icon: <TrendingDown className="w-5 h-5" />,
      title: 'Weak Topic Alert',
      description: 'Focus on Quantum Mechanics - Your accuracy is 45%',
      color: 'from-red-600 to-orange-600',
      action: 'Start Revision',
    },
    {
      icon: <BookMarked className="w-5 h-5" />,
      title: 'Recommended Materials',
      description: 'New interactive lessons on Thermodynamics available',
      color: 'from-blue-600 to-cyan-600',
      action: 'View Materials',
    },
    {
      icon: <Zap className="w-5 h-5" />,
      title: 'Daily Learning Goal',
      description: 'Complete 3 Physics quizzes and 2 Chemistry lessons',
      color: 'from-yellow-600 to-orange-600',
      action: 'Start Now',
    },
  ];

  return (
    <div className="sticky top-24 space-y-4">
      <div className="flex items-center gap-2 mb-6">
        <Lightbulb className="w-6 h-6 text-yellow-500" />
        <h3 className="text-xl font-bold text-white">AI Insights</h3>
      </div>

      {recommendations.map((rec, idx) => (
        <div key={idx} className="bg-card border border-border rounded-xl p-5 hover:border-primary/50 transition-all">
          <div className={`w-10 h-10 bg-gradient-to-br ${rec.color} rounded-lg flex items-center justify-center text-white mb-3`}>
            {rec.icon}
          </div>
          <h4 className="text-white font-semibold mb-2 text-sm">{rec.title}</h4>
          <p className="text-slate-400 text-xs mb-4">{rec.description}</p>
          <button className={`w-full bg-gradient-to-r ${rec.color} text-white font-medium py-2 rounded-lg hover:shadow-lg transition-shadow text-sm`}>
            {rec.action}
          </button>
        </div>
      ))}

      {/* Smart Revision Planner */}
      <div className="bg-gradient-to-br from-purple-600/20 to-pink-600/20 border border-purple-500/50 rounded-xl p-5">
        <h4 className="text-white font-semibold mb-3">Smart Revision Planner</h4>
        <div className="space-y-2 text-sm text-slate-300">
          <p>📅 Monday: Physics - Mechanics</p>
          <p>📅 Tuesday: Chemistry - Organic</p>
          <p>📅 Wednesday: Math - Calculus</p>
          <p>📅 Thursday: Biology - Genetics</p>
        </div>
      </div>
    </div>
  );
}
