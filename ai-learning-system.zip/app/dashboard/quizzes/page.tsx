'use client';

import QuizModule from '@/components/QuizModule';

export default function QuizzesPage() {
  return <QuizModule />;
}
