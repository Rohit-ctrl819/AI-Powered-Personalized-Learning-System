'use client';

import { useRouter, usePathname } from 'next/navigation';
import { BarChart3, BookOpen, LogOut, Settings } from 'lucide-react';
import { useState } from 'react';

export default function DashboardNav() {
  const router = useRouter();
  const pathname = usePathname();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = () => {
    router.push('/');
  };

  const isActive = (path: string) => pathname === path;

  return (
    <nav className="fixed top-0 left-0 right-0 bg-card/80 backdrop-blur-lg border-b border-border z-50">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
            <span className="text-white font-bold text-lg">AI</span>
          </div>
          <div>
            <h1 className="text-white font-bold text-lg">EduAI</h1>
            <p className="text-xs text-slate-400">Learning Platform</p>
          </div>
        </div>

        {/* Navigation Links - Desktop */}
        <div className="hidden md:flex items-center gap-8">
          <a
            href="/dashboard"
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
              isActive('/dashboard')
                ? 'bg-primary/20 text-primary'
                : 'text-slate-400 hover:text-white hover:bg-background/50'
            }`}
          >
            <BookOpen className="w-5 h-5" />
            Dashboard
          </a>
          <a
            href="/dashboard/quizzes"
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
              isActive('/dashboard/quizzes')
                ? 'bg-primary/20 text-primary'
                : 'text-slate-400 hover:text-white hover:bg-background/50'
            }`}
          >
            <BarChart3 className="w-5 h-5" />
            Quizzes
          </a>
          <a
            href="/dashboard/analytics"
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
              isActive('/dashboard/analytics')
                ? 'bg-primary/20 text-primary'
                : 'text-slate-400 hover:text-white hover:bg-background/50'
            }`}
          >
            <BarChart3 className="w-5 h-5" />
            Analytics
          </a>
        </div>

        {/* User Menu */}
        <div className="flex items-center gap-4">
          <button className="p-2 hover:bg-background/50 rounded-lg transition-colors text-slate-400 hover:text-white">
            <Settings className="w-5 h-5" />
          </button>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 bg-destructive/10 text-destructive hover:bg-destructive/20 rounded-lg font-medium transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="md:hidden p-2 hover:bg-background/50 rounded-lg transition-colors text-slate-400 hover:text-white"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden border-t border-border bg-background/50 backdrop-blur">
          <div className="px-6 py-4 space-y-2">
            <a
              href="/dashboard"
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors block ${
                isActive('/dashboard')
                  ? 'bg-primary/20 text-primary'
                  : 'text-slate-400 hover:text-white hover:bg-background/50'
              }`}
            >
              <BookOpen className="w-5 h-5" />
              Dashboard
            </a>
            <a
              href="/dashboard/quizzes"
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors block ${
                isActive('/dashboard/quizzes')
                  ? 'bg-primary/20 text-primary'
                  : 'text-slate-400 hover:text-white hover:bg-background/50'
              }`}
            >
              <BarChart3 className="w-5 h-5" />
              Quizzes
            </a>
            <a
              href="/dashboard/analytics"
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors block ${
                isActive('/dashboard/analytics')
                  ? 'bg-primary/20 text-primary'
                  : 'text-slate-400 hover:text-white hover:bg-background/50'
              }`}
            >
              <BarChart3 className="w-5 h-5" />
              Analytics
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}
