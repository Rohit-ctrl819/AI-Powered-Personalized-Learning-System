'use client';

import { useState } from 'react';
import { CheckCircle, XCircle, ArrowRight, RotateCcw } from 'lucide-react';

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

interface Quiz {
  id: number;
  title: string;
  subject: string;
  questions: QuizQuestion[];
  difficulty: 'Easy' | 'Medium' | 'Hard';
  color: string;
}

export default function QuizModule() {
  const quizzes: Quiz[] = [
    {
      id: 1,
      title: 'Newton&apos;s Laws of Motion',
      subject: 'Physics',
      difficulty: 'Medium',
      color: 'from-blue-600 to-cyan-500',
      questions: [
        {
          id: 1,
          question: 'What is Newton&apos;s First Law of Motion?',
          options: [
            'An object at rest stays at rest unless acted upon by a force',
            'Force equals mass times acceleration',
            'For every action, there is an equal and opposite reaction',
            'Energy cannot be created or destroyed',
          ],
          correct: 0,
          explanation: 'Newton&apos;s First Law states that objects in motion tend to stay in motion unless acted upon by an external force.',
        },
        {
          id: 2,
          question: 'What is F = ma commonly known as?',
          options: [
            'Newton&apos;s First Law',
            'Newton&apos;s Second Law',
            'Newton&apos;s Third Law',
            'Law of Universal Gravitation',
          ],
          correct: 1,
          explanation: 'F = ma is Newton&apos;s Second Law, which relates force, mass, and acceleration.',
        },
        {
          id: 3,
          question: 'If a car suddenly stops, why do passengers feel pushed forward?',
          options: [
            'The car pushes them forward',
            'Their inertia keeps them moving forward',
            'The brakes create a forward force',
            'Gravity affects their movement',
          ],
          correct: 1,
          explanation: 'Due to inertia (Newton&apos;s First Law), passengers continue moving forward when the car stops.',
        },
      ],
    },
    {
      id: 2,
      title: 'Photosynthesis Basics',
      subject: 'Biology',
      difficulty: 'Easy',
      color: 'from-green-600 to-emerald-500',
      questions: [
        {
          id: 1,
          question: 'What is the main purpose of photosynthesis?',
          options: [
            'To break down glucose for energy',
            'To convert light energy into chemical energy',
            'To produce oxygen for respiration',
            'To absorb water from soil',
          ],
          correct: 1,
          explanation: 'Photosynthesis converts light energy into chemical energy stored in glucose.',
        },
        {
          id: 2,
          question: 'Where does the light-dependent reaction occur?',
          options: [
            'In the stroma',
            'In the chloroplast stacks (thylakoids)',
            'In the mitochondria',
            'In the nucleus',
          ],
          correct: 1,
          explanation: 'Light-dependent reactions happen in the thylakoid membranes of chloroplasts.',
        },
        {
          id: 3,
          question: 'Which gas is a product of photosynthesis?',
          options: [
            'Carbon dioxide',
            'Nitrogen',
            'Oxygen',
            'Hydrogen',
          ],
          correct: 2,
          explanation: 'Oxygen is released as a byproduct of photosynthesis during the light reactions.',
        },
      ],
    },
    {
      id: 3,
      title: 'Chemical Bonding',
      subject: 'Chemistry',
      difficulty: 'Hard',
      color: 'from-purple-600 to-pink-500',
      questions: [
        {
          id: 1,
          question: 'What type of bond involves the sharing of electrons?',
          options: [
            'Ionic bond',
            'Covalent bond',
            'Metallic bond',
            'Hydrogen bond',
          ],
          correct: 1,
          explanation: 'Covalent bonds involve the sharing of electron pairs between atoms.',
        },
        {
          id: 2,
          question: 'In an ionic bond, what is transferred?',
          options: [
            'Bonds',
            'Protons',
            'Electrons',
            'Neutrons',
          ],
          correct: 2,
          explanation: 'Ionic bonds form when electrons are transferred from one atom to another.',
        },
        {
          id: 3,
          question: 'Which statement about hydrogen bonds is true?',
          options: [
            'They are the strongest type of bond',
            'They are much weaker than covalent bonds',
            'They involve complete electron transfer',
            'They only occur in ionic compounds',
          ],
          correct: 1,
          explanation: 'Hydrogen bonds are weaker than covalent bonds but important for molecular structure.',
        },
      ],
    },
  ];

  const [selectedQuiz, setSelectedQuiz] = useState<number | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [submitted, setSubmitted] = useState(false);

  const quiz = selectedQuiz !== null ? quizzes[selectedQuiz] : null;

  const handleAnswerSelect = (optionIndex: number) => {
    if (!submitted) {
      const newAnswers = [...answers];
      newAnswers[currentQuestion] = optionIndex;
      setAnswers(newAnswers);
    }
  };

  const handleSubmitQuestion = () => {
    if (currentQuestion < quiz!.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setSubmitted(true);
    }
  };

  const calculateScore = () => {
    if (!quiz) return 0;
    const correct = quiz.questions.filter((q, idx) => answers[idx] === q.correct).length;
    return Math.round((correct / quiz.questions.length) * 100);
  };

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setAnswers([]);
    setSubmitted(false);
    setSelectedQuiz(null);
  };

  if (selectedQuiz === null) {
    return (
      <div className="min-h-screen bg-background p-6 md:p-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold text-white mb-2">Quiz Module</h1>
          <p className="text-slate-400 text-lg mb-12">Test your knowledge with interactive quizzes</p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {quizzes.map((q, idx) => (
              <div
                key={q.id}
                className="bg-card border border-border rounded-2xl p-6 hover:border-primary/50 transition-all cursor-pointer group"
                onClick={() => setSelectedQuiz(idx)}
              >
                <div className={`w-12 h-12 bg-gradient-to-br ${q.color} rounded-lg flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform`}>
                  📝
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{q.title}</h3>
                <p className="text-slate-400 text-sm mb-4">{q.subject}</p>

                <div className="flex items-center justify-between mb-6">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold bg-gradient-to-r ${q.color} text-white`}>
                    {q.difficulty}
                  </span>
                  <span className="text-slate-500 text-sm">{q.questions.length} Questions</span>
                </div>

                <button className={`w-full bg-gradient-to-r ${q.color} text-white font-semibold py-3 rounded-lg hover:shadow-lg transition-shadow flex items-center justify-center gap-2 group-hover:gap-3`}>
                  Start Quiz
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (submitted) {
    const score = calculateScore();
    const correct = quiz.questions.filter((q, idx) => answers[idx] === q.correct).length;

    return (
      <div className="min-h-screen bg-background p-6 md:p-8 flex items-center justify-center">
        <div className="max-w-2xl w-full bg-card border border-border rounded-2xl p-8">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-green-600 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">Quiz Completed!</h1>
            <p className="text-slate-400">Great effort on {quiz.title}</p>
          </div>

          <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-border rounded-xl p-8 mb-8">
            <div className="text-center">
              <p className="text-slate-400 text-sm mb-2">Your Score</p>
              <p className="text-6xl font-bold text-transparent bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text mb-2">
                {score}%
              </p>
              <p className="text-slate-300">
                {correct} out of {quiz.questions.length} correct
              </p>
            </div>
          </div>

          {/* Answer Review */}
          <div className="space-y-4 mb-8">
            <h2 className="text-xl font-bold text-white">Answer Review</h2>
            {quiz.questions.map((q, idx) => (
              <div key={q.id} className="bg-background/50 border border-border rounded-lg p-4">
                <div className="flex items-start gap-3 mb-3">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-1 ${
                    answers[idx] === q.correct
                      ? 'bg-green-600 text-white'
                      : 'bg-red-600 text-white'
                  }`}>
                    {answers[idx] === q.correct ? '✓' : '✗'}
                  </div>
                  <div className="flex-1">
                    <p className="text-white font-semibold mb-2">{q.question}</p>
                    <p className="text-slate-400 text-sm mb-2">Your answer: <span className="text-slate-300">{q.options[answers[idx]]}</span></p>
                    {answers[idx] !== q.correct && (
                      <p className="text-green-400 text-sm mb-2">Correct answer: {q.options[q.correct]}</p>
                    )}
                    <p className="text-slate-400 text-sm italic">{q.explanation}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={restartQuiz}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold py-3 rounded-lg hover:shadow-lg transition-shadow flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-5 h-5" />
            Take Another Quiz
          </button>
        </div>
      </div>
    );
  }

  const question = quiz.questions[currentQuestion];
  const isAnswered = answers[currentQuestion] !== undefined;

  return (
    <div className="min-h-screen bg-background p-6 md:p-8">
      <div className="max-w-3xl mx-auto">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-2xl font-bold text-white">{quiz.title}</h2>
            <span className="text-slate-400 font-medium">
              Question {currentQuestion + 1} of {quiz.questions.length}
            </span>
          </div>
          <div className="w-full bg-background rounded-full h-2 border border-border overflow-hidden">
            <div
              className={`bg-gradient-to-r ${quiz.color} h-full transition-all duration-300`}
              style={{ width: `${((currentQuestion + 1) / quiz.questions.length) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Question Card */}
        <div className="bg-card border border-border rounded-2xl p-8 mb-8">
          <h3 className="text-2xl font-bold text-white mb-8">{question.question}</h3>

          {/* Options */}
          <div className="space-y-3 mb-8">
            {question.options.map((option, idx) => (
              <button
                key={idx}
                onClick={() => handleAnswerSelect(idx)}
                disabled={submitted}
                className={`w-full text-left p-4 border-2 rounded-lg transition-all ${
                  answers[currentQuestion] === idx
                    ? `border-primary bg-primary/10 text-white`
                    : 'border-border bg-background/50 text-slate-300 hover:border-primary/50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                    answers[currentQuestion] === idx
                      ? 'border-primary bg-primary'
                      : 'border-slate-400'
                  }`}>
                    {answers[currentQuestion] === idx && <span className="text-white text-sm">✓</span>}
                  </div>
                  <span>{option}</span>
                </div>
              </button>
            ))}
          </div>

          {/* Navigation */}
          <button
            onClick={handleSubmitQuestion}
            disabled={!isAnswered}
            className={`w-full py-3 rounded-lg font-semibold transition-all flex items-center justify-center gap-2 ${
              isAnswered
                ? `bg-gradient-to-r ${quiz.color} text-white hover:shadow-lg`
                : 'bg-slate-700 text-slate-400 cursor-not-allowed'
            }`}
          >
            {currentQuestion === quiz.questions.length - 1 ? 'Submit Quiz' : 'Next Question'}
            {currentQuestion < quiz.questions.length - 1 && <ArrowRight className="w-5 h-5" />}
          </button>
        </div>

        {/* Help Text */}
        {!isAnswered && (
          <p className="text-center text-slate-400">Please select an answer to continue</p>
        )}
      </div>
    </div>
  );
}
