'use client';

import { useState } from 'react';
import { SmilePlus, Zap, AlertCircle, Clock } from 'lucide-react';

interface Emotion {
  name: string;
  level: number;
  icon: string;
  color: string;
  recommendation: string;
}

export default function EmotionAnalysis() {
  const [selectedEmotion, setSelectedEmotion] = useState<number>(0);

  const emotions: Emotion[] = [
    {
      name: 'Focused',
      level: 75,
      icon: '🎯',
      color: 'from-blue-600 to-cyan-500',
      recommendation: 'Great! You&apos;re in the perfect mental state. Continue with complex problem-solving tasks.',
    },
    {
      name: 'Happy',
      level: 60,
      icon: '😊',
      color: 'from-yellow-600 to-orange-500',
      recommendation: 'You&apos;re feeling good! Perfect time to learn new concepts and engage with interactive lessons.',
    },
    {
      name: 'Stressed',
      level: 45,
      icon: '😰',
      color: 'from-red-600 to-orange-500',
      recommendation: 'Take a 10-minute break. Try some breathing exercises or switch to easier revision topics.',
    },
    {
      name: 'Tired',
      level: 30,
      icon: '😴',
      color: 'from-purple-600 to-pink-500',
      recommendation: 'Your energy is low. Consider taking a power nap or doing light review instead of new concepts.',
    },
  ];

  return (
    <div className="bg-card border border-border rounded-2xl p-8">
      <div className="flex items-center gap-3 mb-8">
        <SmilePlus className="w-7 h-7 text-pink-500" />
        <h2 className="text-2xl font-bold text-white">Emotion Analysis Demo</h2>
      </div>

      {/* Demo Info */}
      <div className="bg-background/50 border border-border rounded-lg p-4 mb-8">
        <p className="text-slate-300 text-sm flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-yellow-500" />
          This is a demo showing how emotion detection would provide personalized recommendations
        </p>
      </div>

      {/* Emotion Selector */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
        {emotions.map((emotion, idx) => (
          <button
            key={idx}
            onClick={() => setSelectedEmotion(idx)}
            className={`p-4 rounded-lg border-2 transition-all ${
              selectedEmotion === idx
                ? `border-primary bg-primary/10`
                : 'border-border hover:border-primary/50 bg-background/30'
            }`}
          >
            <div className="text-3xl mb-2">{emotion.icon}</div>
            <p className="text-white font-semibold text-sm">{emotion.name}</p>
            <p className="text-slate-400 text-xs mt-1">{emotion.level}%</p>
          </button>
        ))}
      </div>

      {/* Emotion Details */}
      <div className="bg-gradient-to-r from-background to-background/50 border border-border rounded-xl p-6">
        <div className="flex items-center gap-4 mb-6">
          <div className={`w-16 h-16 bg-gradient-to-br ${emotions[selectedEmotion].color} rounded-xl flex items-center justify-center text-4xl`}>
            {emotions[selectedEmotion].icon}
          </div>
          <div>
            <h3 className="text-2xl font-bold text-white">{emotions[selectedEmotion].name}</h3>
            <p className="text-slate-400">Current Emotion Level</p>
          </div>
        </div>

        {/* Emotion Meter */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <p className="text-slate-400 text-sm">Confidence Level</p>
            <span className={`text-lg font-bold bg-gradient-to-r ${emotions[selectedEmotion].color} bg-clip-text text-transparent`}>
              {emotions[selectedEmotion].level}%
            </span>
          </div>
          <div className="w-full bg-background rounded-full h-3 overflow-hidden border border-border">
            <div
              className={`bg-gradient-to-r ${emotions[selectedEmotion].color} h-full rounded-full transition-all duration-500`}
              style={{ width: `${emotions[selectedEmotion].level}%` }}
            ></div>
          </div>
        </div>

        {/* Recommendation */}
        <div className="bg-background/50 border border-border rounded-lg p-4">
          <div className="flex items-start gap-3">
            <Zap className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-1" />
            <div>
              <p className="text-white font-semibold mb-1">Recommended Learning Strategy</p>
              <p className="text-slate-300 text-sm">{emotions[selectedEmotion].recommendation}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tips */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
        <div className="bg-background/50 border border-border rounded-lg p-4">
          <div className="text-2xl mb-2">🧠</div>
          <p className="text-white font-semibold text-sm mb-2">Focus Tips</p>
          <p className="text-slate-400 text-xs">Eliminate distractions and take short breaks</p>
        </div>
        <div className="bg-background/50 border border-border rounded-lg p-4">
          <div className="text-2xl mb-2">⏰</div>
          <p className="text-white font-semibold text-sm mb-2">Best Study Time</p>
          <p className="text-slate-400 text-xs">You study best between 9-11 AM and 3-5 PM</p>
        </div>
        <div className="bg-background/50 border border-border rounded-lg p-4">
          <div className="text-2xl mb-2">🎯</div>
          <p className="text-white font-semibold text-sm mb-2">Optimal Duration</p>
          <p className="text-slate-400 text-xs">45 minutes study + 10 minutes break works best</p>
        </div>
      </div>
    </div>
  );
}
