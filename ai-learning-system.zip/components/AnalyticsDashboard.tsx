'use client';

import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Calendar, Target, Clock } from 'lucide-react';

export default function AnalyticsDashboard() {
  // Weekly study data
  const weeklyData = [
    { day: 'Mon', hours: 2.5, quizzes: 3, lessons: 4 },
    { day: 'Tue', hours: 3.0, quizzes: 4, lessons: 5 },
    { day: 'Wed', hours: 2.8, quizzes: 3, lessons: 4 },
    { day: 'Thu', hours: 4.2, quizzes: 5, lessons: 6 },
    { day: 'Fri', hours: 3.5, quizzes: 4, lessons: 5 },
    { day: 'Sat', hours: 5.0, quizzes: 6, lessons: 7 },
    { day: 'Sun', hours: 3.8, quizzes: 4, lessons: 5 },
  ];

  // Subject performance data
  const subjectData = [
    { name: 'Mathematics', value: 78, color: '#3b82f6' },
    { name: 'Physics', value: 72, color: '#8b5cf6' },
    { name: 'Chemistry', value: 85, color: '#10b981' },
    { name: 'Biology', value: 68, color: '#f97316' },
  ];

  // Monthly progress
  const monthlyProgress = [
    { week: 'Week 1', completion: 65, accuracy: 72 },
    { week: 'Week 2', completion: 72, accuracy: 75 },
    { week: 'Week 3', completion: 70, accuracy: 78 },
    { week: 'Week 4', completion: 85, accuracy: 82 },
  ];

  const COLORS = ['#3b82f6', '#8b5cf6', '#10b981', '#f97316'];

  return (
    <div className="min-h-screen bg-background p-6 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold text-white mb-2">Learning Analytics</h1>
          <p className="text-slate-400 text-lg">Detailed insights into your learning progress</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <StatCard
            icon={<Clock className="w-6 h-6" />}
            label="Total Hours"
            value="24.3"
            subtext="This month"
            color="from-blue-600 to-cyan-500"
          />
          <StatCard
            icon={<Target className="w-6 h-6" />}
            label="Avg Accuracy"
            value="79%"
            subtext="Across all quizzes"
            color="from-purple-600 to-pink-500"
          />
          <StatCard
            icon={<Calendar className="w-6 h-6" />}
            label="Study Streak"
            value="12"
            subtext="Days in a row"
            color="from-orange-600 to-red-500"
          />
          <StatCard
            icon={<TrendingUp className="w-6 h-6" />}
            label="Progress"
            value="72%"
            subtext="Overall completion"
            color="from-green-600 to-emerald-500"
          />
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Weekly Study Hours */}
          <div className="lg:col-span-2 bg-card border border-border rounded-2xl p-6">
            <h2 className="text-xl font-bold text-white mb-6">Weekly Study Pattern</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="day" stroke="#cbd5e1" />
                <YAxis stroke="#cbd5e1" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1a2847', border: '1px solid #334155', borderRadius: '8px' }}
                  labelStyle={{ color: '#fff' }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="hours"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  dot={{ fill: '#3b82f6', r: 5 }}
                  name="Hours Studied"
                />
                <Line
                  type="monotone"
                  dataKey="quizzes"
                  stroke="#8b5cf6"
                  strokeWidth={2}
                  dot={{ fill: '#8b5cf6', r: 5 }}
                  name="Quizzes Taken"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Subject Performance Pie */}
          <div className="bg-card border border-border rounded-2xl p-6">
            <h2 className="text-xl font-bold text-white mb-6">Subject Performance</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={subjectData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {COLORS.map((color, index) => (
                    <Cell key={`cell-${index}`} fill={color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#1a2847', border: '1px solid #334155', borderRadius: '8px' }}
                  labelStyle={{ color: '#fff' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Monthly Progress */}
        <div className="bg-card border border-border rounded-2xl p-6">
          <h2 className="text-xl font-bold text-white mb-6">Monthly Progress</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={monthlyProgress}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="week" stroke="#cbd5e1" />
              <YAxis stroke="#cbd5e1" />
              <Tooltip
                contentStyle={{ backgroundColor: '#1a2847', border: '1px solid #334155', borderRadius: '8px' }}
                labelStyle={{ color: '#fff' }}
              />
              <Legend />
              <Bar dataKey="completion" fill="#3b82f6" name="Completion %" radius={[8, 8, 0, 0]} />
              <Bar dataKey="accuracy" fill="#8b5cf6" name="Accuracy %" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Detailed Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-card border border-border rounded-xl p-6">
            <h3 className="text-white font-semibold mb-4">Quiz Statistics</h3>
            <div className="space-y-3">
              <StatRow label="Total Quizzes" value="28" />
              <StatRow label="Passed" value="24" />
              <StatRow label="Average Score" value="79%" />
              <StatRow label="Best Subject" value="Chemistry" />
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-6">
            <h3 className="text-white font-semibold mb-4">Learning Goals</h3>
            <div className="space-y-3">
              <ProgressBar label="Daily Study Goal" percentage={75} />
              <ProgressBar label="Weekly Target" percentage={68} />
              <ProgressBar label="Monthly Goal" percentage={72} />
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-6">
            <h3 className="text-white font-semibold mb-4">Achievements</h3>
            <div className="space-y-3">
              <AchievementItem emoji="🏆" text="Perfect Score" date="2 days ago" />
              <AchievementItem emoji="🔥" text="12 Day Streak" date="Today" />
              <AchievementItem emoji="⭐" text="500 Points" date="5 days ago" />
            </div>
          </div>
        </div>

        {/* Recommendations */}
        <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-border rounded-2xl p-8">
          <h2 className="text-2xl font-bold text-white mb-4">Personalized Insights</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <p className="text-slate-300 text-sm mb-2">📊 <span className="font-semibold">Strong Areas</span></p>
              <p className="text-slate-400">Chemistry and Mathematics are your strongest subjects with 85% and 78% respectively.</p>
            </div>
            <div>
              <p className="text-slate-300 text-sm mb-2">⚠️ <span className="font-semibold">Areas for Improvement</span></p>
              <p className="text-slate-400">Biology (68%) could use more focus. Try more interactive lessons and practice quizzes.</p>
            </div>
            <div>
              <p className="text-slate-300 text-sm mb-2">⏰ <span className="font-semibold">Optimal Study Time</span></p>
              <p className="text-slate-400">You perform best between 9-11 AM and 3-5 PM. Schedule important topics during these times.</p>
            </div>
            <div>
              <p className="text-slate-300 text-sm mb-2">🎯 <span className="font-semibold">Next Milestone</span></p>
              <p className="text-slate-400">You&apos;re 12% away from reaching 80% overall accuracy. Keep up the great work!</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: string;
  subtext: string;
  color: string;
}

function StatCard({ icon, label, value, subtext, color }: StatCardProps) {
  return (
    <div className="bg-card border border-border rounded-xl p-6 hover:border-primary/50 transition-all">
      <div className={`w-12 h-12 bg-gradient-to-br ${color} rounded-lg flex items-center justify-center text-white mb-4`}>
        {icon}
      </div>
      <p className="text-slate-400 text-sm font-medium mb-2">{label}</p>
      <p className="text-2xl font-bold text-white mb-1">{value}</p>
      <p className="text-xs text-slate-500">{subtext}</p>
    </div>
  );
}

function StatRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-border">
      <span className="text-slate-400 text-sm">{label}</span>
      <span className="text-white font-semibold">{value}</span>
    </div>
  );
}

function ProgressBar({ label, percentage }: { label: string; percentage: number }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <span className="text-slate-400 text-sm">{label}</span>
        <span className="text-white font-semibold text-sm">{percentage}%</span>
      </div>
      <div className="w-full bg-background rounded-full h-2 overflow-hidden border border-border">
        <div
          className="bg-gradient-to-r from-blue-600 to-purple-600 h-full transition-all duration-300"
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );
}

function AchievementItem({ emoji, text, date }: { emoji: string; text: string; date: string }) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-border">
      <div className="flex items-center gap-2">
        <span className="text-xl">{emoji}</span>
        <span className="text-white text-sm">{text}</span>
      </div>
      <span className="text-slate-500 text-xs">{date}</span>
    </div>
  );
}
